# ParseRealtimeQuery
A submodule for unity projects allowing for Realtime Queries for the Parse system 

There is a test scene and test script that shows how to use the system

I have tested on iOS Android Windows and UWP

Currently it does not work on UWP due to some file acsess issues with Parse, not sure if it is a bug or if I am not using it right
