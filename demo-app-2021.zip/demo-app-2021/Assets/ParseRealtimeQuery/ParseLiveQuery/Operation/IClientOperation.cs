﻿namespace Parse.LiveQuery {
    public interface IClientOperation {

        string ToJson();

    }
}
