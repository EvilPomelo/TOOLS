﻿namespace Parse.LiveQuery {
    public enum WebSocketClientState {
        None,
        Connecting,
        Connected,
        Disconnecting,
        Disconnected
    }
}
