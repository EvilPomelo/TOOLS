using System.Runtime.CompilerServices;

[assembly:InternalsVisibleTo("ParseLiveQuery.Test")]